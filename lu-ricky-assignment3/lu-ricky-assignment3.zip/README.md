# Requirements
1. Latest version of python2 be installed, I used python 2.7.18
2. Other core libraries should be installed by default with python2

# Running the program 
```
For linux 
python2 sample_pinger.py (IP address/Host name you want to ping)
```
This will ping the IP address/Host name that you specified at a one second interval. Press ctrl + c anytime to stop the program and see the packet analysis.

# Reports
The report is included in the pdf file named "Programming Assignment 3 Report"